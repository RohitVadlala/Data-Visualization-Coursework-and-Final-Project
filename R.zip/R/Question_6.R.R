install.packages("dplyr")
install.packages("ggplot2")
install.packages("readxl")
install.packages("tidyverse")


library(dplyr)
library(ggplot2)
library(readxl)
library(tidyverse)
# Adjust the paths to where your CSV files are stored
covid_data_part1 <- read.csv("C:/Users/vadla/Downloads/2020 Cases only_RS.csv")
covid_data_part2 <- read.csv("C:/Users/vadla/Downloads/2021 Cases only_RS.csv")


df_2020 <- subset(covid_data_part1, select = -c(OBJECTID))
names(df_2020)[names(df_2020) == 'ObjectId2'] <- 'ObjectId'
combined_covid_data <- rbind(df_2020, covid_data_part2)


# Filter data for the specified counties
filtered_data <- combined_covid_data %>%
  filter(County %in% c("Suwannee", "Monroe", "Hardee", "Walton"))

# Ensure correct ordering of counties for plotting
filtered_data$County <- factor(filtered_data$County, levels = c("Suwannee", "Monroe", "Hardee", "Walton"))

# Convert EventDate to proper date format and handle Case_ column
summarized_data <- filtered_data %>%
  mutate(EventDate = as.Date(EventDate, format = "%m/%d/%Y"),  # Convert EventDate to date format
         Case_ = ifelse(Case_ == "Yes", 1, 0)) %>%  # Convert Case_ to numeric (1 for "Yes", 0 otherwise)
  group_by(EventDate, County) %>%  # Group by EventDate and County
  summarise(TotalCases = sum(Case_))  # Summarise total cases for each group

# Create a plot using ggplot2
ggplot(summarized_data, aes(x = EventDate, y = TotalCases)) +
  geom_line(color = 'blue') +  # Line plot for total cases
  facet_wrap(~ County, nrow = 2) +  # Facet by County with 2 rows
  labs(x = "Date", y = "Total Cases", title = "Total COVID-19 Cases by County") 
   






