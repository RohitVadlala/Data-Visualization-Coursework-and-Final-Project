library(ggplot2)
library(readxl)
library(dplyr)
library(zoo)

# Load the data from the 'Hillsborough' sheet
hillsborough_data <- read_excel("C:/Users/vadla/Downloads/Combined (1).xlsx", sheet = "Hillsborough")

# Set the column names manually
colnames(hillsborough_data) <- c("Date", "Daily_Cases", "Moving_Average")

# Convert 'Date' from character to Date type, specifying the format "March 1, 2020"
hillsborough_data$Date <- as.Date(hillsborough_data$Date, format = "%B %d, %Y")

# Plotting both daily cases and moving average
ggplot(hillsborough_data, aes(x = Date)) +
  geom_col(aes(y = Moving_Average), fill = "gray", alpha = 0.5, width = 0.7) +  # columns for Moving Average
  geom_line(aes(y = Daily_Cases), color = "blue", size = 1.2) +  # line for Daily Cases
  labs(title = "COVID-19 Daily Cases and Moving Average in Hillsborough",
       x = "Date",
       y = "Number of Cases",
       caption = "Data source: Hillsborough COVID-19 Data") +
  theme_minimal() +
  scale_y_continuous("Cases", sec.axis = sec_axis(~., name = "Moving Average"))
