install.packages("dplyr")
install.packages("ggplot2")
install.packages("readxl")

library(dplyr)
library(ggplot2)
library(readxl)

# Adjust the paths to where your CSV files are stored
covid_data_part1 <- read.csv("C:/Users/vadla/Downloads/2020 Cases only_RS.csv")
covid_data_part2 <- read.csv("C:/Users/vadla/Downloads/2021 Cases only_RS.csv")


df_2020 <- subset(covid_data_part1, select = -c(OBJECTID))
names(df_2020)[names(df_2020) == 'ObjectId2'] <- 'ObjectId'
combined_covid_data <- rbind(df_2020, covid_data_part2)




# Check for missing values
summary(combined_covid_data)

# Convert date columns to Date type if necessary
combined_covid_data$EventDate <- as.Date(combined_covid_data$EventDate, format = "%Y-%m-%d")

# Remove duplicate rows if necessary
combined_covid_data <- unique(combined_covid_data)

# Save the combined data to a new CSV file
write.csv(combined_covid_data, "combined_covid_data.csv", row.names = FALSE)
