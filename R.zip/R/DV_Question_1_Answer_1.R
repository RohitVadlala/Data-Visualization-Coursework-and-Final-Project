install.packages("ggplot2")
install.packages("readxl")
install.packages("tidyverse")


library(ggplot2)
library(readxl)
data <- read_excel("C:/Users/vadla/Downloads/2018 Data.xlsx")
print(colnames(data))
# Create scatter plot using the correct column names with backticks
ggplot(data, aes(x = `Mean Family Income`, y = `Perc with health Insurance`, size = `Unemployment Rate`)) +
  geom_point(shape = 3, color = "green") +  # Shape 3 is a plus
  scale_size_continuous(name = "Unemployment Rate") +
  labs(x = "Mean Family Income", y = "Percentage with Health Insurance", title = "Income vs. Health Insurance Coverage") +
  theme_minimal()