
install.packages("ggplot2")
install.packages("readxl")
install.packages("dplyr")

# Load the packages
library(ggplot2)
library(readxl)
library(dplyr)

# Adjust the path to where your Excel file is stored
data <- read_excel("C:/Users/vadla/Downloads/Simplified Car Sales Data (1).xlsx")

# Filter data for specified countries and summarize sales by color
filtered_data <- data %>%
  filter(CountryName %in% c("Spain", "Switzerland", "France")) %>%
  group_by(CountryName, Color) %>%
  summarise(Total_Sales = sum(SalePrice), .groups = 'drop')

# Creating a clustered column chart
ggplot(filtered_data, aes(x = Color, y = Total_Sales, fill = CountryName)) +
  geom_col(position = position_dodge(width = 0.9), width = 0.8) +
  labs(title = "Car Sales by Color in Spain, Switzerland, and France",
       x = "Color",
       y = "Total Sales",
       fill = "Country") +
  theme_minimal()
