install.packages("ggplot2")
install.packages("readxl")
install.packages("dplyr")
install.packages("zoo")


# Load necessary libraries
library(ggplot2)
library(readxl)
library(dplyr)
library(zoo)

# Ensure the correct path to the Excel file and correct sheet name are used
file_path <- "C:/Users/vadla/Downloads/Combined (1).xlsx"
sheet_name <- "Pasco"


# Attempt to read the data from the specified sheet
# Check if the file exists and the sheet exists
if (file.exists(file_path)) {
  # List all sheets to confirm the presence of the 'Pasco' sheet
  sheets <- excel_sheets(file_path)
  print(sheets) # Print available sheets to verify
  
  if (sheet_name %in% sheets) {
    pasco_data <- read_excel(file_path, sheet = sheet_name)
    
    # Assign column names manually
    colnames(pasco_data) <- c("Date", "Daily_Cases", "Moving_Average")
    
    # Print the first few rows of the dataset to confirm data is loaded
    print(head(pasco_data))
    
    # Plotting the data
    ggplot(pasco_data, aes(x = Date)) +
      geom_line(aes(y = Daily_Cases), color = "blue", size = 1, linetype = "solid") +
      geom_line(aes(y = Moving_Average), color = "red", size = 1, linetype = "dashed") +
      labs(title = "COVID-19 Daily Cases and Moving Average in Pasco",
           x = "Date",
           y = "Number of Cases") +
      theme_minimal()
  } else {
    print(paste("The sheet", sheet_name, "does not exist in the file."))
  }
} else {
  print(paste("The file", file_path, "does not exist. Please check the path."))
}
